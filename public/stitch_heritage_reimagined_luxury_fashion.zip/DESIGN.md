---
name: Atelier Vayu
colors:
  surface: '#fef9f0'
  surface-dim: '#ded9d1'
  surface-bright: '#fef9f0'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f8f3ea'
  surface-container: '#f2ede4'
  surface-container-high: '#ece8df'
  surface-container-highest: '#e7e2d9'
  on-surface: '#1d1c16'
  on-surface-variant: '#534343'
  inverse-surface: '#32302a'
  inverse-on-surface: '#f5f0e7'
  outline: '#867273'
  outline-variant: '#d8c1c1'
  surface-tint: '#91484d'
  primary: '#2d0006'
  on-primary: '#ffffff'
  primary-container: '#4a1118'
  on-primary-container: '#c9757a'
  inverse-primary: '#ffb3b5'
  secondary: '#725b31'
  on-secondary: '#ffffff'
  secondary-container: '#fedea9'
  on-secondary-container: '#786137'
  tertiary: '#141008'
  on-tertiary: '#ffffff'
  tertiary-container: '#2a251c'
  on-tertiary-container: '#948c7f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdada'
  primary-fixed-dim: '#ffb3b5'
  on-primary-fixed: '#3c060e'
  on-primary-fixed-variant: '#743137'
  secondary-fixed: '#fedea9'
  secondary-fixed-dim: '#e1c290'
  on-secondary-fixed: '#271900'
  on-secondary-fixed-variant: '#58431c'
  tertiary-fixed: '#ebe1d3'
  tertiary-fixed-dim: '#cfc5b8'
  on-tertiary-fixed: '#1f1b12'
  on-tertiary-fixed-variant: '#4c463c'
  background: '#fef9f0'
  on-background: '#1d1c16'
  surface-variant: '#e7e2d9'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 4.5rem
    fontWeight: '400'
    lineHeight: 5rem
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 2.75rem
    fontWeight: '400'
    lineHeight: 3.25rem
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 3rem
    fontWeight: '400'
    lineHeight: 3.5rem
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 2rem
    fontWeight: '400'
    lineHeight: 2.5rem
    letterSpacing: 0em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 2.25rem
    fontWeight: '400'
    lineHeight: 2.75rem
    letterSpacing: 0em
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 1.5rem
    fontWeight: '500'
    lineHeight: 2rem
    letterSpacing: 0.01em
  title-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: 0.04em
  body-lg:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '300'
    lineHeight: 1.75rem
    letterSpacing: 0.01em
  body-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '300'
    lineHeight: 1.5rem
    letterSpacing: 0.015em
  label-lg:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.18em
  label-md:
    fontFamily: Inter
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: 0.875rem
    letterSpacing: 0.22em
  label-sm:
    fontFamily: Inter
    fontSize: 0.625rem
    fontWeight: '500'
    lineHeight: 0.75rem
    letterSpacing: 0.25em
spacing:
  gutter: 1.5rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2.5rem
  margin: 1.5rem
  margin-tablet: 3rem
  margin-desktop: 5rem
  space-xs: 0.375rem
  space-sm: 0.75rem
  space-md: 1.5rem
  space-lg: 2.5rem
  space-xl: 4.5rem
---

## Brand & Style

The brand personifies contemporary Indian haute couture and quiet luxury—rooted in traditional textile architecture, distilled through modern, austere restraint. The visual language balances ancestral craft with forward-facing architectural form. It avoids visual clutter, loud ornamentation, and commercial frenzy in favor of gallery-grade editorial pacing, monumental negative space, and museum-like reverence for textile details.

The design movement synthesizes **Minimalism** with **Editorial High-Fashion**. 
- The tone conveys stillness, discipline, and uncompromising craft.
- Spatial dynamics rely on asymmetric grid alignment, oversized editorial margins, and deliberate pauses between collections.
- Visual elements borrow from museum curation: fine hairline dividers reminiscent of bespoke pattern drafting, tactile tonal shifts, and typography scaled with stark contrasts between sweeping headlines and minute, tracked-out metadata.

## Colors

The palette establishes an organic, archival canvas rooted in raw silks, vegetable dyes, and hand-beaten brass:

- **Primary (`#4A1118` - Deep Maroon):** Used for commanding focal points, active states, key interactive labels, and editorial anchors. It invokes historical Indian madder root dyeing while retaining an understated, dignified presence.
- **Secondary (`#A58A5C` - Muted Antique Brass):** Reserved for delicate metallic accents, subtle collection tags, refined hairline boundaries, and active indicators.
- **Tertiary (`#E8DED0` - Soft Cream):** Supplies structural depth across tonal containers, alternate product backdrops, subtle card backgrounds, and interactive hover fills.
- **Neutral (`#F4EFE6` - Warm Ivory):** The primary canvas background color. It replaces sterile digital whites with the warmth of unbleached silk and handmade paper.
- **Neutral Variant (`#171313` - Near Black):** The primary color for long-form narrative prose, specifications, and primary product headlines, providing high legibility without digital glare.

Use high tonal restraint: backgrounds remain predominantly `#F4EFE6` with `#E8DED0` surface layering. Never deploy pure black (`#000000`) or pure white (`#FFFFFF`).

## Typography

The type system stages an interplay between editorial classicism and clinical modernity:

- **Playfair Display:** Imparts an editorial cadence. Headlines must be styled primarily in sentence case or classical roman casing; avoid forced all-caps in headlines. Use generous line heights to preserve breathing room between descenders and ascenders.
- **Inter:** Chosen for navigation, micro-labels, pricing, and narrative text. Body copy adopts a light weight (`300`) with relaxed line-height for effortless long-form reading.
- **Micro-Labels & Technical Specifications:** All uppercase labels (`label-lg`, `label-md`, `label-sm`) require tracking between `0.18em` and `0.25em`. This distinct typographic treatment evokes museum provenance tags and architectural blueprints.

## Layout & Spacing

The structural layout utilizes an asymmetric 12-column grid on desktop, a 6-column grid on tablet, and a 4-column fluid grid on mobile:

- **Editorial Cadence:** Stagger collection listings and lookbooks across asymmetrical spans (e.g., a 7-column primary visual paired with an offset 4-column textual column, separated by a single-column void).
- **Whitespace Allocation:** White space functions as a structural element rather than unused space. Canvas margins scale up to `5rem` on wide viewports to compress content inward, producing an intimate, book-like presentation.
- **Vertical Spacing Rhythm:** Section-to-section transitions use multiples of `space-xl` (ranging from `4.5rem` to `9rem`) to force deliberative scrolling and distinct separation between couture chapters.
- **Breakpoints:**
  - Mobile: `< 768px` (Single column dominant; stacked imagery and descriptions; sticky discreet navigation).
  - Tablet: `768px – 1024px` (Balanced two-column modules; expanded gutters).
  - Desktop: `> 1024px` (Full editorial asymmetric rhythm with generous canvas margins).

## Elevation & Depth

Visual hierarchy rejects simulated drop shadows, plastic blurs, and skeuomorphic layers in favor of **Tonal Layers** and **Architectural Hairlines**:

- **Hairline Boundaries:** Separation is achieved using crisp `1px` solid borders colored with muted brass (`rgba(165, 138, 92, 0.3)`) or deep neutral tints (`rgba(23, 19, 19, 0.1)`). 
- **Surface Layering:** Depth is communicated strictly via plane shifts—placing primary content on `#F4EFE6`, layered above or adjacent to `#E8DED0` inset panels.
- **Floating Contexts & Overlays:** For drawers, quick views, and modal panels, employ an opaque `#F4EFE6` background framed by a `1px` border in `#E8DED0`. Pair with a backdrop curtain composed of `#171313` at `35%` opacity with no blur, maintaining sharp graphic clarity.
- **Micro-Hover States:** Hover states forgo elevation lift or physical displacement. Visual feedback occurs strictly through subtle color transmutations (e.g., border transition from muted brass to deep maroon) over `400ms cubic-bezier(0.25, 1, 0.5, 1)`.

## Shapes

The architectural integrity of the brand mandates a **strict 0px corner radius across all elements**:

- Buttons, product cards, inputs, tags, dialog overlays, and badges have razor-sharp square edges.
- This non-rounded geometric discipline references pattern grading sheets, looms, architectural stone plinths, and traditional gallery displays.
- Visual rhythm comes from aspect ratios (such as vertical `4:5` and `2:3` editorial image crops) rather than soft radiuses.

## Components

### Buttons & Interactive Links
- **Primary Buttons:** Solid `#4A1118` fill, `#F4EFE6` text, styled in `label-md` uppercase with `0.22em` letter spacing. 0px border radius, padding: `1.125rem 2.5rem`. Hover state shifts background to `#171313` via a smooth 300ms transition.
- **Secondary / Outline Buttons:** Transparent background, `1px` solid `#4A1118` or `#A58A5C` border, text colored in `#4A1118`. On hover, the fill shifts to `#4A1118` with `#F4EFE6` text.
- **Editorial Text Links:** Plain `label-md` text with a permanent `1px` bottom underline offset by `6px`. Hover state smoothly transitions underline width or opacity.

### Form Inputs & Select Fields
- **Form Controls:** Minimalist bottom-line-only or 4-sided `1px` hairline containers in `rgba(23, 19, 19, 0.2)` on `#F4EFE6`. No border radius.
- **Text & Placeholder:** Input text is rendered in `body-md` (`#171313`); floating labels use `label-sm` tracking (`#A58A5C`).
- **Focus State:** Hairline switches to solid `#4A1118` with zero ring or glow effects.

### Checkboxes & Radios
- **Checkboxes:** Custom `14px x 14px` squares, `1px` hairline border in `#171313`. Active state displays an interior solid fill in `#4A1118` inset by `2px`.
- **Radio Buttons:** Custom `14px x 14px` squares (preserving the 0px shape language) with an interior centered square pip when selected.

### Product & Editorial Cards
- **Product Cards:** Frameless, minimal composition. Image sits in a `4:5` vertical aspect ratio against a muted warm backdrop.
- **Typography Integration:** Below the visual asset, metadata is structured in `label-sm` (Collection / Craft discipline) followed by `headline-sm` (Piece name) and `body-md` (Price/Availability).
- **Hover Interactivity:** Subtle secondary image cross-fade over `600ms ease`. No translation or drop shadow.

### Chips & Badges
- **Editorial Chips:** Sharp-edged rectangular badges with a `1px` border in `#A58A5C` and a background of `#F4EFE6` or `#E8DED0`.
- **Typography:** `label-sm`, all caps, tracked out to `0.25em`. Used selectively for textile descriptors (e.g., "HAND-WOVEN CHANDERI", "RAW MULBERRY SILK").

### Textile Narrative & Spec Drawers
- **Slide-out Panels:** Clean rectilinear drawers extending full height on the right screen boundary, enclosed with a left `1px` border in `#E8DED0`.
- **Content Hierarchy:** Generous `space-lg` internal padding, featuring macro close-ups of weave patterns alongside provenance copy rendered in `body-lg`.